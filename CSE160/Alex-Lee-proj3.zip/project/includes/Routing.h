#ifndef ROUTING_H
#define ROUTING_H

typedef struct Route{
    uint16_t cost;
    uint16_t next_hop;
}

#endif /* ROUTING_h *
